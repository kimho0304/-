//package kr.ac.kookmin.cs;

public class PPoint {
    int xA; 
    int yA;
    /** 클래스 필드 선언
    * PPoint 생성자 선언
    */
    public PPoint(int x, int y) {
        xA = x;
        yA = y;
    };
    
    /**
     * xA 게터 함수
     */
    public int getX() {
        return xA;
    }

    /**
    *yA 게터 함수
     */
    public int getY() {
        return yA;
    }
}
