package kr.ac.kookmin.cs;

public class PPoint {
    int xA;
    int yA;
    public PPoint(int x, int y) {
        xA = x;
        yA = y;
    };
    public int getX() {
        return xA;
    }
    public int getY() {
        return yA;
    }
}
