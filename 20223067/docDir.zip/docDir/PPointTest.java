package kr.otherpkg;
import kr.ac.kookmin.cs.*;

class PPointTest {
    public static void main(String args[]) {
        PPoint aObj = new PPoint(10, 20);
        System.out.println("aObj(x, y) = " + aObj.getX() + ", "+ aObj.getY());
    }
}
